"""Vacation rental property scraper package."""
__version__ = "1.0.0"
