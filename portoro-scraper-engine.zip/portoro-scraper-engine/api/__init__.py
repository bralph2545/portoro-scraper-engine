"""FastAPI web application for the scraper system."""
__version__ = "1.0.0"
